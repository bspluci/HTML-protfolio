<?php


class N2SmartsliderBackendInstallController extends N2SmartSliderController {

    public function initialize() {
    }

    public function actionIndex($secured = false) {
    }
} 